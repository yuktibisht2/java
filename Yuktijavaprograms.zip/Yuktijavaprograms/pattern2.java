class pattern2{
public static void main(String[] args)
{
    int n =7;
    for (int i=0;i<n;i++)
    {
        //print 5 stars in a row
        for(int j=0; j<n;j++)
        {
            System.out.print("*");
        }
        // ln takes cursor to new line
        System.out.println(" ");
        
    }
}
}